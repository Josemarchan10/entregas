<?php
require ('../connection/connection.php');

$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$direccion = $_POST['direccion'];

$query = "INSERT INTO contactos (nombre,telefono,email,direccion) VALUES ('$nombre', '$telefono', '$email', '$direccion')";
$ejecutar = mysqli_query($connection, $query);
header("Location: ../index.php");

?>