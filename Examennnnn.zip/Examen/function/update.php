<?php
require ('../connection/connection.php');

$id = $_GET['id'];
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$email = $_POST['email'];
$direccion = $_POST['direccion'];

$query = "UPDATE contactos SET nombre = '$nombre', telefono = '$telefono', email = '$email', direccion = '$direccion' WHERE id_contacto = '$id'";

$ejecutar = mysqli_query($connection, $query);

header("Location: ../index.php");
?>