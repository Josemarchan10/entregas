<nav class="navbar bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" >
      <img src="https://images.vexels.com/media/users/3/206164/isolated/preview/9c2166c157dce721fdaaeec772e03c0b-icono-de-trazo-de-agenda-rosa.png" alt="Logo" width="70" height="56" class="d-inline-block align-text-top">
    </a>
    <H1 style="color:#FFFFFF">Agenda de contactos</H1><B>
  </div>
</nav>