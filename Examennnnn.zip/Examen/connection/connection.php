<?php

$hostname = "mysql-josemarchanb.alwaysdata.net";
$username = "331560";
$password = "Josegregorio10";
$database = "josemarchanb_base_de_datos";

$connection = mysqli_connect($hostname, $username, $password, $database);

if (!$connection){
    die("Conexión fallida: " . mysqli_connect_error());
}

?>