CREATE TABLE contactos(
    id_contacto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50),
    telefono VARCHAR(13),
    email VARCHAR(50),
    direccion VARCHAR(100)
);